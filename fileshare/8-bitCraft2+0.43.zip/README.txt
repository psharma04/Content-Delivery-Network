Thank you for downloading 8-bitCraft 2!

This pack was created by Tobik and you are not allowed to distribute/modify this pack's 
textures commercially without permission, however, you can use modify these textures for your personal use.
All rights reserved. Submit your feedback on either Planet Minecraft or CurseForge.

Please be aware that if you see 8-bitCraft 2 submitted on other sites, it wasn't uploaded by me.
If the download link on that page redirects you to CurseForge, then it's fine. Otherwise, anything you download
is out of my control and you're probably getting the old version.

Which reminds me, this pack will be regularly updated until finished. For more information visit CurseForge.

This pack was created using RPW - Resource Pack Workbench. Software which makes making packs a lot easier.

Alright, enjoy the pack. The game version and pack version are stated in the pack's description (in-game).
If the version is lower than 1, the version doesn't include all textures.
